hotel_bookings <- read.csv("hotel_bookings.csv")
head(hotel_bookings)

#organizing in colnames
colnames(hotel_bookings)
#"I want to target people who book early, and I have a hypothesis that people with children have to book in advance."
#Now Arranging the long datasets in Clear form
#Lets add the Title , caption ,and subtitles corresponding with size ,shape and colour.
min(hotel_bookings$arrival_date_year)
max(hotel_bookings$arrival_date_year)
minimun <- min(hotel_bookings$arrival_date_year)
maximum <- max(hotel_bookings$arrival_date_year)
ggplot(data = hotel_bookings) +
  geom_bar(mapping = aes(x = market_segment)) +
  facet_wrap(~hotel) + labs(title="Comparison of market segments by hotel type for hotel bookings",
                            subtitle=("Data from: ", minimun, " to ", maximum))
#NOW SAVE THE Files By using Export and ggsave() function
ggsave("hotel_bookings.png",width = 7,height = 7)

